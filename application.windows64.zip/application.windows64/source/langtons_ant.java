import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class langtons_ant extends PApplet {

int dir;
int x, y;
PImage canvas;

public void setup() {
  dir = 0;
  background(0);
  x = 200;
  y = 200;
  
  //fullScreen();
  canvas = createImage(width, height, RGB);
  for (int q = 0; q < canvas.pixels.length; q ++) {
    canvas.pixels[q] = color(255);
  }
}
public void draw() {
  for (int w = 0; w < 100; w++) {
    Move(x, y);
    image(canvas, 0, 0);
  }
}
public void turnRight() {
  dir++;
  if (dir == 4) {
    dir = 0;
  }
}
public void turnLeft() {
  dir--;
  if (dir == -1) {
    dir = 3;
  }
}
public void Move(int i, int j) {
  canvas.loadPixels();
  int index = i + j * canvas.width;
  if (canvas.pixels[index] == color(0)) {
    turnRight();
    canvas.pixels[index] = color(255);
  } else if (canvas.pixels[index] == color(255)) {
    turnLeft();
    canvas.pixels[index] = color(0);
  }
  if (dir == 0) {
    //up
    y--;
    if (y < 0) {
      y = height-1;
    }
  } else if (dir == 1) {
    //right
    x++;
    if (x >= width) {
      x = 0;
    }
  } else if (dir == 2) {
    //down
    y++;
    if (y >= height) {
      y = 0;
    }
  } else if (dir == 3) {
    //left
    x--;
    if (x < 0) {
      x = width-1;
    }
  }
  canvas.updatePixels();
}
  public void settings() {  size(400, 400); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#666666", "--stop-color=#cccccc", "langtons_ant" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
